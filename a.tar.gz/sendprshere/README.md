delet
